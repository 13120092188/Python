#extension GL_OES_standard_derivatives : enable
precision mediump float;

void main()
{
    gl_FragColor = vec4(0.0,0.0,0.0, 0.0);
}


